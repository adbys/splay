package adt.splaytree;

import adt.bst.BST;

public interface SplayTree<T extends Comparable<T>> extends BST<T> {

}
